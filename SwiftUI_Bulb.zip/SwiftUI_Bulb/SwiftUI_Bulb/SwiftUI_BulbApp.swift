//
//  SwiftUI_BulbApp.swift
//  SwiftUI_Bulb
//
//  Created by SMH on 20/06/24.
//

import SwiftUI

@main
struct SwiftUI_BulbApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
