//
//  ContentView.swift
//  SwiftUI_Bulb
//
//  Created by SMH on 20/06/24.
//

import SwiftUI

struct ContentView: View {
    @State private var brightness: Double = 0.0
    @State private var increasing: Bool = true
    @State private var timer: Timer? = nil
    @State private var showStars: Bool = false
    @State private var rotation: Double = 0.0
    
    var body: some View {
        VStack {
            
            // Shimmering title centered at the top
            ShimmeringBubbles(text: "Shimmering Light Animation")
                .font(.system(size: 36, weight: .bold))
                .foregroundColor(.white)
                .padding(.top, 0) // Top padding for the app name
            
            Spacer() // Spacer to push content to the top
            
            ZStack {
                // Circle representation for brightness control
                Circle()
                    .stroke(Color.gray, lineWidth: 2)
                    .background(Circle().fill(Color.yellow).opacity(brightness))
                    .frame(width: 150, height: 150)
                    .shadow(radius: 10)
                    .animation(.easeInOut(duration: 0.2), value: brightness)
                
                // Rotating stars around the circle
                if showStars {
                    ForEach(0..<10) { index in
                        StarShape()
                            .fill(Color.red)
                            .frame(width: 10, height: 10)
                            .offset(y: -90)
                            .rotationEffect(.degrees(rotation + Double(index) * 36))
                    }
                }
            }
            .overlay(
                Rectangle()
                    .fill(Color.gray)
                    .frame(width: 2, height: 155)
                    .offset(y: 150)
            )
            
            Spacer() // Spacer to push content to the top
            
            // Button to toggle brightness
            Button(action: {
                if timer == nil {
                    startTimer()
                } else {
                    stopTimer()
                }
            }) {
                Text(increasing ? "Hold to Increase Brightness" : "Hold to Decrease Brightness")
                    .padding()
                    .background(increasing ? Color.green : Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .onLongPressGesture(minimumDuration: .infinity, pressing: { pressing in
                if pressing {
                    startTimer()
                } else {
                    stopTimer()
                }
            }) {
                // Do nothing
            }
            
            Spacer() // Spacer to push content to the top
        }
        .padding()
        .background(
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.2, green: 0.2, blue: 0.6), // Light black color
                    Color(red: 1.0, green: 0.0, blue: 0.0, opacity: 0.7) // Light red color with opacity
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .edgesIgnoringSafeArea(.all)
        )
    }
    
    // Function to start increasing/decreasing brightness with animation
    private func startTimer() {
        stopTimer() // Stop any existing timer
        
        showStars = true // Show stars animation
        
        // Create a timer to animate brightness and rotation
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            withAnimation(.easeInOut(duration: 0.1)) {
                if increasing {
                    brightness += 0.05 // Increase brightness
                    rotation += 10 // Rotate stars
                    if brightness >= 1.0 {
                        brightness = 1.0 // Cap brightness at 1.0
                        increasing = false // Switch to decreasing mode
                    }
                } else {
                    brightness -= 0.05 // Decrease brightness
                    rotation -= 10 // Rotate stars
                    if brightness <= 0.0 {
                        brightness = 0.0 // Cap brightness at 0.0
                        increasing = true // Switch to increasing mode
                    }
                }
            }
        }
    }
    
    // Function to stop the timer and hide stars animation
    private func stopTimer() {
        timer?.invalidate() // Invalidate the timer
        timer = nil // Reset timer
        
        showStars = false // Hide stars animation
    }
}

// Star shape defined as a custom SwiftUI Shape
struct StarShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let starExtrusion: CGFloat = 5
        
        let center = CGPoint(x: rect.width / 2, y: rect.height / 2)
        
        let pointsOnStar = 5
        
        var angle: CGFloat = -CGFloat.pi / 2
        
        let angleIncrement = .pi * 2 / CGFloat(pointsOnStar)
        let radius = rect.width / 2
        let midRadius = radius * starExtrusion / 10
        
        for i in 0..<pointsOnStar * 2 {
            let length = i % 2 == 0 ? radius : midRadius
            let point = CGPoint(x: center.x + cos(angle) * length, y: center.y + sin(angle) * length)
            if i == 0 {
                path.move(to: point)
            } else {
                path.addLine(to: point)
            }
            angle += angleIncrement / 2
        }
        
        path.closeSubpath() // Close the path to complete the star
        
        return path
    }
}

// ShimmeringBubbles with rainbow colors
struct ShimmeringBubbles: View {
    let text: String
    @State private var isAnimating: Bool = false
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(Array(text.enumerated()), id: \.offset) { index, char in
                Text(String(char))
                    .font(.system(size: 36, weight: .bold))
                    .foregroundColor(rainbowColor(forIndex: index))
                    .opacity(isAnimating ? 1.0 : 0.5)
                    .offset(y: isAnimating ? -5 : 0)
            }
        }
        .onAppear {
            withAnimation(Animation.easeInOut(duration: 1.5).repeatForever()) {
                self.isAnimating = true
            }
        }
    }
    
    // Function to generate rainbow colors based on index
    private func rainbowColor(forIndex index: Int) -> Color {
        let colors: [Color] = [
            .red, .white, .red, .white, .white, .orange, .yellow, .pink, .purple
        ]
        let colorIndex = index % colors.count
        return colors[colorIndex]
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

